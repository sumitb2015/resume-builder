import { useState } from "react";

const defaultResume = {
  name: "David Kowalski",
  title: "Senior Game Designer & Content Engine Specialist",
  photo: "https://i.pravatar.cc/150?img=11",
  contact: {
    email: "david.kowalski@gmail.com",
    phone: "+1 (206) 491-4750",
    location: "Seattle, WA",
    linkedin: "linkedin.com/in/davidk",
    portfolio: "davidk.design",
  },
  summary:
    "Passionate game developer with 5+ years of professional experience creating engaging gameplay systems and polished player experiences across multiple platforms. Specialized in Unity and Unreal Engine with strong expertise in C#, C++, and game design principles.",
  technicalSkills: [
    { name: "Unity Engine", level: 5 },
    { name: "Unreal Engine", level: 4 },
    { name: "C# / C++", level: 5 },
    { name: "Game AI", level: 4 },
    { name: "3D Modeling", level: 3 },
    { name: "Shader Programming", level: 3 },
  ],
  programmingLanguages: [
    { name: "C#", level: 5 },
    { name: "C++", level: 4 },
    { name: "Python", level: 3 },
    { name: "HLSL/GLSL", level: 3 },
  ],
  education: [
    {
      degree: "Bachelor of Science — CS",
      school: "University of Washington",
      date: "2014 — 2018",
      gpa: "3.8",
    },
  ],
  certifications: [
    "Unity Certified Expert Programmer — March 2021",
    "Unreal Engine 5.0+ Developer — Oct 2022",
    "AWS Certified Developer — 2023",
  ],
  awards: [{ title: "Best Gameplay Engineer", org: "GDC Awards", date: "2023", detail: "Top 1%" }],
  experience: [
    {
      role: "Lead Game Developer",
      company: "Cascade Studios",
      location: "Seattle, WA",
      period: "March 2021 — Present",
      bullets: [
        "Architected core combat system resulting in 40% improvement in player engagement metrics.",
        "Developed custom editor tools in C++ that reduced designer iteration time by 60%.",
        "Implemented procedural generation systems for level layouts, enemy encounters, and loot drops.",
        "Led cross-functional team of 8 engineers delivering 3 major game updates on schedule.",
      ],
    },
    {
      role: "Mid-Level Game Developer",
      company: "PostFrag Interactive",
      location: "Bellevue, WA",
      period: "June 2020 — Feb 2022",
      bullets: [
        "Core developer on Shattered Odyssey — sci-fi roguelite with 50,000+ sales in first month.",
        "Implemented procedural generation system for level layouts and loot drops using Unity and C#.",
        "Created save/load system supporting cloud saves and cross-platform play between PC and Switch.",
      ],
    },
  ],
  languages: [{ name: "English", level: "Native" }],
};

function SkillDots({ level, max = 5 }) {
  return (
    <span style={{ display: "inline-flex", gap: 3 }}>
      {Array.from({ length: max }).map((_, i) => (
        <span key={i} style={{
          width: 7, height: 7, borderRadius: "50%",
          background: i < level ? "#14b8a6" : "#334155",
          display: "inline-block",
        }} />
      ))}
    </span>
  );
}

function SideLabel({ children }) {
  return (
    <div style={{
      fontSize: 9, fontWeight: 700, letterSpacing: "0.13em",
      textTransform: "uppercase", color: "#5eead4",
      borderBottom: "1px solid rgba(94,234,212,0.25)",
      paddingBottom: 4, marginBottom: 8, marginTop: 16,
    }}>
      {children}
    </div>
  );
}

function MainLabel({ children }) {
  return (
    <div style={{
      fontSize: 9, fontWeight: 700, letterSpacing: "0.13em",
      textTransform: "uppercase", color: "#0d9488",
      borderBottom: "1.5px solid #ccfbf1",
      paddingBottom: 4, marginBottom: 10, marginTop: 16,
    }}>
      {children}
    </div>
  );
}

function Dot() {
  return (
    <span style={{
      width: 5, height: 5, borderRadius: "50%",
      background: "#0d9488", display: "inline-block",
      flexShrink: 0, marginTop: 5,
    }} />
  );
}

export default function BronzorPreview() {
  const [scale, setScale] = useState(0.72);
  const r = defaultResume;

  return (
    <div style={{ background: "#e2e8f0", minHeight: "100vh", padding: "20px 0" }}>
      {/* Controls */}
      <div style={{
        display: "flex", alignItems: "center", justifyContent: "center",
        gap: 12, marginBottom: 16, fontFamily: "sans-serif",
      }}>
        <span style={{ fontSize: 12, color: "#475569", fontWeight: 600 }}>BRONZOR TEMPLATE PREVIEW</span>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontSize: 11, color: "#64748b" }}>Zoom</span>
          <input type="range" min="40" max="100" value={Math.round(scale * 100)}
            onChange={e => setScale(e.target.value / 100)}
            style={{ width: 80 }} />
          <span style={{ fontSize: 11, color: "#64748b", minWidth: 32 }}>{Math.round(scale * 100)}%</span>
        </div>
      </div>

      {/* Resume scaled container */}
      <div style={{ display: "flex", justifyContent: "center" }}>
        <div style={{
          transform: `scale(${scale})`,
          transformOrigin: "top center",
          width: 794,
          marginBottom: `calc((${scale} - 1) * 1123px)`,
        }}>
          <div style={{
            width: 794, minHeight: 1123, background: "#fff",
            fontFamily: "'Segoe UI', system-ui, sans-serif",
            boxShadow: "0 8px 40px rgba(0,0,0,0.18)",
          }}>
            {/* HEADER */}
            <div style={{
              background: "linear-gradient(135deg, #0f766e 0%, #0d9488 60%, #14b8a6 100%)",
              padding: "26px 32px 22px",
              display: "flex", alignItems: "center", gap: 22,
            }}>
              <img src={r.photo} alt={r.name} style={{
                width: 86, height: 86, borderRadius: "50%",
                border: "3px solid rgba(255,255,255,0.55)",
                objectFit: "cover", flexShrink: 0,
              }} />
              <div style={{ flex: 1 }}>
                <div style={{
                  fontSize: 26, fontWeight: 700, color: "#fff",
                  letterSpacing: "-0.02em", lineHeight: 1.1, marginBottom: 3,
                }}>{r.name}</div>
                <div style={{
                  fontSize: 12, color: "#99f6e4", fontWeight: 500,
                  marginBottom: 11, letterSpacing: "0.02em",
                }}>{r.title}</div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: "5px 18px" }}>
                  {[
                    ["✉", r.contact.email],
                    ["☎", r.contact.phone],
                    ["📍", r.contact.location],
                    ["in", r.contact.linkedin],
                    ["🌐", r.contact.portfolio],
                  ].map(([icon, val], i) => val && (
                    <span key={i} style={{ fontSize: 10, color: "#ccfbf1", display: "flex", alignItems: "center", gap: 4 }}>
                      <span style={{ opacity: 0.75 }}>{icon}</span>{val}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* BODY */}
            <div style={{ display: "flex", flex: 1 }}>
              {/* SIDEBAR */}
              <div style={{ width: 212, background: "#0f172a", padding: "18px 16px", flexShrink: 0 }}>
                <SideLabel>Summary</SideLabel>
                <p style={{ fontSize: 10, color: "#94a3b8", lineHeight: 1.65, margin: 0 }}>{r.summary}</p>

                <SideLabel>Technical Skills</SideLabel>
                {r.technicalSkills.map((s, i) => (
                  <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                    <span style={{ fontSize: 10, color: "#e2e8f0" }}>{s.name}</span>
                    <SkillDots level={s.level} />
                  </div>
                ))}

                <SideLabel>Programming</SideLabel>
                {r.programmingLanguages.map((s, i) => (
                  <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                    <span style={{ fontSize: 10, color: "#e2e8f0" }}>{s.name}</span>
                    <SkillDots level={s.level} />
                  </div>
                ))}

                <SideLabel>Education</SideLabel>
                {r.education.map((e, i) => (
                  <div key={i} style={{ marginBottom: 10 }}>
                    <div style={{ fontSize: 10, fontWeight: 600, color: "#f1f5f9" }}>{e.degree}</div>
                    <div style={{ fontSize: 9.5, color: "#94a3b8", marginTop: 2 }}>{e.school}</div>
                    <div style={{ fontSize: 9.5, color: "#64748b", marginTop: 1 }}>{e.date}</div>
                    {e.gpa && <div style={{ fontSize: 9.5, color: "#14b8a6", marginTop: 1 }}>GPA: {e.gpa}</div>}
                  </div>
                ))}

                <SideLabel>Certifications</SideLabel>
                {r.certifications.map((c, i) => (
                  <div key={i} style={{
                    fontSize: 9.5, color: "#cbd5e1", marginBottom: 6,
                    paddingLeft: 7, borderLeft: "2px solid #14b8a6", lineHeight: 1.45,
                  }}>{c}</div>
                ))}

                <SideLabel>Awards</SideLabel>
                {r.awards.map((a, i) => (
                  <div key={i} style={{ marginBottom: 8 }}>
                    <div style={{ fontSize: 10, fontWeight: 600, color: "#f1f5f9" }}>{a.title}</div>
                    <div style={{ fontSize: 9.5, color: "#94a3b8" }}>{a.org} · {a.date}</div>
                    {a.detail && <div style={{ fontSize: 9.5, color: "#14b8a6" }}>{a.detail}</div>}
                  </div>
                ))}
              </div>

              {/* MAIN */}
              <div style={{ flex: 1, padding: "18px 26px" }}>
                <MainLabel>Professional Experience</MainLabel>
                {r.experience.map((exp, i) => (
                  <div key={i} style={{ marginBottom: 18 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 3 }}>
                      <div>
                        <div style={{ fontSize: 13, fontWeight: 700, color: "#111827", letterSpacing: "-0.01em" }}>{exp.role}</div>
                        <div style={{ fontSize: 10.5, color: "#0d9488", fontWeight: 600, marginTop: 1 }}>
                          {exp.company}
                          <span style={{ color: "#9ca3af", fontWeight: 400 }}> · {exp.location}</span>
                        </div>
                      </div>
                      <div style={{
                        fontSize: 9.5, color: "#6b7280",
                        background: "#f3f4f6", padding: "2px 7px",
                        borderRadius: 4, whiteSpace: "nowrap", marginTop: 2,
                      }}>{exp.period}</div>
                    </div>
                    <div style={{ marginTop: 6 }}>
                      {exp.bullets.map((b, j) => (
                        <div key={j} style={{ display: "flex", gap: 7, marginBottom: 5, alignItems: "flex-start" }}>
                          <Dot />
                          <span style={{ fontSize: 11, color: "#374151", lineHeight: 1.55 }}>{b}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}

                <MainLabel>Languages</MainLabel>
                <div style={{ display: "flex", gap: 10 }}>
                  {r.languages.map((l, i) => (
                    <div key={i} style={{
                      fontSize: 10.5, color: "#0f766e",
                      background: "#f0fdf9", border: "1px solid #99f6e4",
                      padding: "3px 10px", borderRadius: 4,
                    }}>
                      {l.name}{l.level && <span style={{ color: "#9ca3af", marginLeft: 4 }}>— {l.level}</span>}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
