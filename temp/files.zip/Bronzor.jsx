// components/templates/Bronzor.jsx
// A professional two-column resume template with photo header and teal accent
// Usage: <Bronzor resume={resumeData} />

import React from "react";

// ─── Default sample data (replace with your real data schema) ────────────────
const defaultResume = {
  name: "David Kowalski",
  title: "Senior Game Designer & Content Engine Specialist",
  photo: "https://i.pravatar.cc/150?img=11",
  contact: {
    email: "david.kowalski@gmail.com",
    phone: "+1 (206) 491-4750",
    location: "Seattle, WA",
    linkedin: "linkedin.com/in/davidk",
    portfolio: "davidk.design",
  },
  summary:
    "Passionate game developer with 5+ years of professional experience creating engaging gameplay systems and polished player experiences across multiple platforms. Specialized in Unity and Unreal Engine with strong expertise in C#, C++, and game design principles.",
  technicalSkills: [
    { name: "Unity Engine", level: 5 },
    { name: "Unreal Engine", level: 4 },
    { name: "C# / C++", level: 5 },
    { name: "Game AI", level: 4 },
    { name: "3D Modeling", level: 3 },
    { name: "Shader Programming", level: 3 },
  ],
  programmingLanguages: [
    { name: "C#", level: 5 },
    { name: "C++", level: 4 },
    { name: "Python", level: 3 },
    { name: "HLSL/GLSL", level: 3 },
  ],
  education: [
    {
      degree: "Bachelor of Science — CS, GPA",
      school: "University of Washington",
      field: "Computer Science",
      date: "2014 — 2018",
      gpa: "3.8",
    },
  ],
  certifications: [
    "Unity Certified Expert Programmer — March 2021",
    "Unreal Engine 5.0+ Developer — Oct 2022",
    "AWS Certified Developer — 2023",
  ],
  awards: [
    {
      title: "Best Gameplay Engineer",
      org: "GDC Awards",
      date: "2023",
      detail: "Top 1%",
    },
  ],
  experience: [
    {
      role: "Lead Game Developer",
      company: "Cascade Studios",
      location: "Seattle, WA",
      period: "March 2021 — Present",
      bullets: [
        "Architected and implemented core combat system resulting in 40% improvement in player engagement metrics.",
        "Developed custom editor tools in C++ that reduced designer iteration time by 60% and improved workflow efficiency across the team.",
        "Implemented procedural generation systems for level layouts, enemy encounters, and loot drops using Unity and C#.",
        "Led cross-functional team of 8 engineers delivering 3 major game updates on schedule.",
      ],
    },
    {
      role: "Mid-Level Game Developer",
      company: "PostFrag Interactive",
      location: "Bellevue, WA",
      period: "June 2020 — February 2022",
      bullets: [
        "Core developer on Shattered Odyssey; a sci-fi roguelite that achieved 50,000+ sales in first month.",
        "Implemented procedural generation system for level layouts, enemy encounters, and loot drops using Unity and C#.",
        "Created robust save/load system supporting cloud saves and cross-platform play between PC and Nintendo Switch.",
      ],
    },
  ],
  languages: [{ name: "English", level: "Native" }],
};

// ─── Sub-components ──────────────────────────────────────────────────────────

function SkillDots({ level, max = 5, color = "#0d9488" }) {
  return (
    <span style={{ display: "inline-flex", gap: 3, alignItems: "center" }}>
      {Array.from({ length: max }).map((_, i) => (
        <span
          key={i}
          style={{
            width: 8,
            height: 8,
            borderRadius: "50%",
            background: i < level ? color : "#d1d5db",
            display: "inline-block",
          }}
        />
      ))}
    </span>
  );
}

function SectionTitle({ children, light = false }) {
  return (
    <div
      style={{
        fontSize: 11,
        fontWeight: 700,
        letterSpacing: "0.12em",
        textTransform: "uppercase",
        color: light ? "#99f6e4" : "#0d9488",
        borderBottom: `1.5px solid ${light ? "rgba(255,255,255,0.2)" : "#ccfbf1"}`,
        paddingBottom: 4,
        marginBottom: 10,
        marginTop: 18,
        fontFamily: "'DM Sans', sans-serif",
      }}
    >
      {children}
    </div>
  );
}

function BulletPoint({ children }) {
  return (
    <div style={{ display: "flex", gap: 7, marginBottom: 5, alignItems: "flex-start" }}>
      <span
        style={{
          width: 5,
          height: 5,
          borderRadius: "50%",
          background: "#0d9488",
          marginTop: 6,
          flexShrink: 0,
        }}
      />
      <span style={{ fontSize: 11.5, color: "#374151", lineHeight: 1.55 }}>{children}</span>
    </div>
  );
}

// ─── Main Template ────────────────────────────────────────────────────────────

export default function Bronzor({ resume = defaultResume }) {
  const r = { ...defaultResume, ...resume };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Serif+Display&display=swap');
        .bronzor-wrap * { box-sizing: border-box; }
        .bronzor-wrap { font-family: 'DM Sans', sans-serif; }
      `}</style>

      <div
        className="bronzor-wrap"
        style={{
          width: 794,
          minHeight: 1123,
          background: "#fff",
          display: "flex",
          flexDirection: "column",
          boxShadow: "0 4px 32px rgba(0,0,0,0.12)",
        }}
      >
        {/* ── HEADER ── */}
        <div
          style={{
            background: "linear-gradient(135deg, #0f766e 0%, #0d9488 60%, #14b8a6 100%)",
            padding: "28px 32px 24px",
            display: "flex",
            alignItems: "center",
            gap: 24,
          }}
        >
          {r.photo && (
            <img
              src={r.photo}
              alt={r.name}
              style={{
                width: 90,
                height: 90,
                borderRadius: "50%",
                border: "3px solid rgba(255,255,255,0.6)",
                objectFit: "cover",
                flexShrink: 0,
              }}
            />
          )}
          <div style={{ flex: 1 }}>
            <div
              style={{
                fontFamily: "'DM Serif Display', serif",
                fontSize: 28,
                color: "#fff",
                letterSpacing: "-0.01em",
                lineHeight: 1.1,
                marginBottom: 4,
              }}
            >
              {r.name}
            </div>
            <div
              style={{
                fontSize: 13,
                color: "#99f6e4",
                fontWeight: 500,
                marginBottom: 12,
                letterSpacing: "0.02em",
              }}
            >
              {r.title}
            </div>
            {/* Contact row */}
            <div style={{ display: "flex", flexWrap: "wrap", gap: "6px 20px" }}>
              {[
                { icon: "✉", value: r.contact.email },
                { icon: "☎", value: r.contact.phone },
                { icon: "📍", value: r.contact.location },
                { icon: "in", value: r.contact.linkedin },
                { icon: "🌐", value: r.contact.portfolio },
              ]
                .filter((c) => c.value)
                .map((c, i) => (
                  <span
                    key={i}
                    style={{ fontSize: 10.5, color: "#ccfbf1", display: "flex", alignItems: "center", gap: 4 }}
                  >
                    <span style={{ fontSize: 10, opacity: 0.8 }}>{c.icon}</span>
                    {c.value}
                  </span>
                ))}
            </div>
          </div>
        </div>

        {/* ── BODY: two columns ── */}
        <div style={{ display: "flex", flex: 1 }}>
          {/* LEFT SIDEBAR */}
          <div
            style={{
              width: 220,
              background: "#0f172a",
              padding: "20px 18px",
              flexShrink: 0,
            }}
          >
            {/* Professional Summary */}
            <SectionTitle light>Summary</SectionTitle>
            <p style={{ fontSize: 10.5, color: "#cbd5e1", lineHeight: 1.65, margin: 0 }}>
              {r.summary}
            </p>

            {/* Technical Skills */}
            <SectionTitle light>Technical Skills</SectionTitle>
            {r.technicalSkills.map((s, i) => (
              <div
                key={i}
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom: 7,
                }}
              >
                <span style={{ fontSize: 10.5, color: "#e2e8f0" }}>{s.name}</span>
                <SkillDots level={s.level} color="#14b8a6" />
              </div>
            ))}

            {/* Programming Languages */}
            <SectionTitle light>Languages</SectionTitle>
            {r.programmingLanguages.map((s, i) => (
              <div
                key={i}
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom: 7,
                }}
              >
                <span style={{ fontSize: 10.5, color: "#e2e8f0" }}>{s.name}</span>
                <SkillDots level={s.level} color="#14b8a6" />
              </div>
            ))}

            {/* Education */}
            <SectionTitle light>Education</SectionTitle>
            {r.education.map((e, i) => (
              <div key={i} style={{ marginBottom: 10 }}>
                <div style={{ fontSize: 10.5, fontWeight: 600, color: "#f1f5f9" }}>{e.degree}</div>
                <div style={{ fontSize: 10, color: "#94a3b8", marginTop: 2 }}>{e.school}</div>
                <div style={{ fontSize: 10, color: "#64748b", marginTop: 1 }}>{e.date}</div>
                {e.gpa && (
                  <div style={{ fontSize: 10, color: "#14b8a6", marginTop: 2 }}>GPA: {e.gpa}</div>
                )}
              </div>
            ))}

            {/* Certifications */}
            {r.certifications?.length > 0 && (
              <>
                <SectionTitle light>Certifications</SectionTitle>
                {r.certifications.map((c, i) => (
                  <div
                    key={i}
                    style={{
                      fontSize: 10,
                      color: "#cbd5e1",
                      marginBottom: 6,
                      paddingLeft: 8,
                      borderLeft: "2px solid #14b8a6",
                      lineHeight: 1.4,
                    }}
                  >
                    {c}
                  </div>
                ))}
              </>
            )}

            {/* Awards */}
            {r.awards?.length > 0 && (
              <>
                <SectionTitle light>Awards</SectionTitle>
                {r.awards.map((a, i) => (
                  <div key={i} style={{ marginBottom: 8 }}>
                    <div style={{ fontSize: 10.5, fontWeight: 600, color: "#f1f5f9" }}>{a.title}</div>
                    <div style={{ fontSize: 10, color: "#94a3b8" }}>{a.org} · {a.date}</div>
                    {a.detail && (
                      <div style={{ fontSize: 10, color: "#14b8a6" }}>{a.detail}</div>
                    )}
                  </div>
                ))}
              </>
            )}
          </div>

          {/* RIGHT MAIN CONTENT */}
          <div style={{ flex: 1, padding: "20px 28px" }}>
            {/* Professional Experience */}
            <SectionTitle>Professional Experience</SectionTitle>

            {r.experience.map((exp, i) => (
              <div key={i} style={{ marginBottom: 18 }}>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "flex-start",
                    marginBottom: 3,
                  }}
                >
                  <div>
                    <div
                      style={{
                        fontSize: 13,
                        fontWeight: 700,
                        color: "#111827",
                        fontFamily: "'DM Serif Display', serif",
                      }}
                    >
                      {exp.role}
                    </div>
                    <div style={{ fontSize: 11, color: "#0d9488", fontWeight: 600 }}>
                      {exp.company}
                      {exp.location && (
                        <span style={{ color: "#9ca3af", fontWeight: 400 }}>
                          {" "}· {exp.location}
                        </span>
                      )}
                    </div>
                  </div>
                  <div
                    style={{
                      fontSize: 10,
                      color: "#6b7280",
                      background: "#f3f4f6",
                      padding: "2px 8px",
                      borderRadius: 4,
                      whiteSpace: "nowrap",
                      marginTop: 2,
                    }}
                  >
                    {exp.period}
                  </div>
                </div>
                <div style={{ marginTop: 6 }}>
                  {exp.bullets.map((b, j) => (
                    <BulletPoint key={j}>{b}</BulletPoint>
                  ))}
                </div>
              </div>
            ))}

            {/* Spoken Languages */}
            {r.languages?.length > 0 && (
              <>
                <SectionTitle>Languages</SectionTitle>
                <div style={{ display: "flex", gap: 16 }}>
                  {r.languages.map((l, i) => (
                    <div
                      key={i}
                      style={{
                        fontSize: 11,
                        color: "#374151",
                        background: "#f0fdf9",
                        border: "1px solid #99f6e4",
                        padding: "3px 10px",
                        borderRadius: 4,
                      }}
                    >
                      {l.name}
                      {l.level && (
                        <span style={{ color: "#9ca3af", marginLeft: 4 }}>— {l.level}</span>
                      )}
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
